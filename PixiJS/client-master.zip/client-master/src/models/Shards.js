export const SHARDS = [
    'steam',
    'xbox',
    'kakao',
]
