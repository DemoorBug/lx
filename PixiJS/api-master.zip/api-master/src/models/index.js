import Player from './Player.js'
import Match from './Match.js'
import MatchPlayer from './MatchPlayer.js'

export default {
    Player,
    Match,
    MatchPlayer,
}
